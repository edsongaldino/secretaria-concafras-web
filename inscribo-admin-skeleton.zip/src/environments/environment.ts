export const environment = {
  production: false,
  apiUrl: 'https://api.seu-dominio.com' // ajuste para o seu endpoint
};
