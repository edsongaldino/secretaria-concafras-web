export function toDateOnlyISO(d: Date | string | null | undefined): string | null {
  if (!d) return null;
  const dt = typeof d === 'string' ? new Date(d) : d;
  const y = dt.getFullYear();
  const m = (dt.getMonth() + 1).toString().padStart(2,'0');
  const day = dt.getDate().toString().padStart(2,'0');
  return `${y}-${m}-${day}`;
}
