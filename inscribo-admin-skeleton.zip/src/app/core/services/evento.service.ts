import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { toDateOnlyISO } from '../utils/dateonly';

@Injectable({ providedIn: 'root' })
export class EventoService {
  private http = inject(HttpClient);
  private base = `${environment.apiUrl}/api/eventos`;

  listar(q: { page: number; pageSize: number; q?: string; sort?: string; dir?: string; }) {
    return this.http.get(`${this.base}`, { params: { ...q as any } });
  }

  criar(dto: any) {
    const body = { ...dto, dataInicio: toDateOnlyISO(dto.dataInicio), dataFim: toDateOnlyISO(dto.dataFim) };
    return this.http.post(this.base, body);
  }

  atualizar(id: string, dto: any) {
    const body = { ...dto, dataInicio: toDateOnlyISO(dto.dataInicio), dataFim: toDateOnlyISO(dto.dataFim) };
    return this.http.put(`${this.base}/${id}`, body);
  }

  remover(id: string) {
    return this.http.delete(`${this.base}/${id}`);
  }
}
