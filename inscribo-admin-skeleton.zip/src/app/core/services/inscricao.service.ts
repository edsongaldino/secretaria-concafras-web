import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class InscricaoService {
  private http = inject(HttpClient);
  private base = `${environment.apiUrl}/api/inscricoes`;

  listar(q: { page: number; pageSize: number; q?: string; sort?: string; dir?: string; }) {
    return this.http.get(`${this.base}`, { params: { ...q as any } });
  }

  atualizar(id: string, dto: any) {
    return this.http.put(`${this.base}/${id}`, dto);
  }
}
