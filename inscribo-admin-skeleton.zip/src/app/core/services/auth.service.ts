import { Injectable, signal } from '@angular/core';

export type PerfilUsuario = 'Participante' | 'Gestor' | 'Coordenador' | 'Financeiro' | 'Secretaria';

interface Sessao {
  logado: boolean;
  perfis: PerfilUsuario[];
  nome?: string;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private _sessao = signal<Sessao>({ logado: true, perfis: ['Gestor','Secretaria'] });

  isLoggedIn() { return this._sessao().logado; }
  hasPerfil(p: PerfilUsuario) { return this._sessao().perfis.includes(p); }
  hasAnyPerfil(perfis: PerfilUsuario[]) { return perfis.some(p => this.hasPerfil(p)); }
  get usuario() { return this._sessao(); }

  // TODO: integrar com JWT da sua API
  login(token: string) { /* guardar token e perfis */ }
  logout() { this._sessao.set({ logado: false, perfis: [] }); }
}
