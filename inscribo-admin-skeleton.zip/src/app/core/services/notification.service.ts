import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class NotificationService {
  success(msg: string, title?: string) { console.log('SUCCESS:', title || '', msg); }
  errorCenter(title: string, msg?: string) { console.error('ERROR:', title, msg || ''); }
}
