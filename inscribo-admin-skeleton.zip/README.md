# Inscribo Admin Skeleton (Angular Material)

Estrutura mínima para o painel admin com **Angular Material** e **ngx-echarts**,
separada em **.ts / .html / .scss**. Use para colar dentro do seu projeto Angular.

## Pré-requisitos
```bash
ng add @angular/material
npm i echarts ngx-echarts
```

No `main.ts`, garanta:
```ts
import 'zone.js';
import { bootstrapApplication } from '@angular/platform-browser';
import { provideHttpClient, withFetch } from '@angular/common/http';
```

## Rotas
O arquivo `src/app/app.routes.ts` inclui lazy loading para `/admin`.

## API
Edite `src/environments/environment.ts` com seu `apiUrl`.

